//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by devicemanager.rc
//
#define IDS_PROJNAME                    100
#define IDR_ATLDeviceManager            100
#define IDR_DEVICE                      101
#define IDR_INFORMATION                 102
#define IDR_INFORMATION1                103
#define IDR_KERNEL                      104
#define IDR_KERNELLOG                   105
#define IDC_MAPLIST                     201
#define IDI_ICON1                       202
#define IDD_DUMMYDIALOG                 203
#define IDD_DIALOG1                     205
#define IDD_MAPLISTDIALOG               205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
