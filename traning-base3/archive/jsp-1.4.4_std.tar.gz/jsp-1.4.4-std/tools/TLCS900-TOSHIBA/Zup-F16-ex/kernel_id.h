#ifndef KERNEL_ID_H
#define KERNEL_ID_H

	/* object identifier deifnition */

#define CYCHDR1              1
#define LOGTASK              5
#define MAIN_TASK            4
#define SERIAL_RCV_SEM1      1
#define SERIAL_SND_SEM1      2
#define TASK1                1
#define TASK2                2
#define TASK3                3

#endif /* KERNEL_ID_H */

