-------- PROJECT GENERATOR --------
PROJECT NAME :	sample
PROJECT DIRECTORY :	C:\jsp\tools\H8-RENESAS\sample
CPU SERIES :	300H
CPU TYPE :	3048F
TOOLCHAIN NAME :	Hitachi H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	6.0.3.0
GENERATION FILES :
    C:\jsp\tools\H8-RENESAS\sample\dbsct.c
        Setting of B,R Section
START ADDRESS OF SECTION :
    H'000000800	P,C,C$DSEC,C$BSEC,D
    H'000FFEF10	B,R
    H'000FFFD00	S

* When the user program is executed,
* the interrupt mask has been masked.
* 
* ****H8/3048f Advanced****

SELECT TARGET :
    H8/3048F-ONE E10T-USB SYSTEM ( CPU H8/300H )
DATE & TIME : 2005/03/14 16:28:09
