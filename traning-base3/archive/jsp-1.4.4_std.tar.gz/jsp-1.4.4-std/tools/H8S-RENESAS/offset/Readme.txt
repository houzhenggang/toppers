-------- PROJECT GENERATOR --------
PROJECT NAME :	offset
PROJECT DIRECTORY :	D:\cygwin\home\Administrator\tmp\jsp-1.4.2.pre5\hew\jsp\tools\H8S-RENESAS\offset
CPU SERIES :	2000
TOOLCHAIN NAME :	Hitachi H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	6.1.0.0

DATE & TIME : 2005/12/06 13:24:40
