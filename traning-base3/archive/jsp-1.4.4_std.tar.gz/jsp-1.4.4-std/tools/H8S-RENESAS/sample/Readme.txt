-------- PROJECT GENERATOR --------
PROJECT NAME :	sample
PROJECT DIRECTORY :	D:\cygwin\home\Administrator\tmp\jsp-1.4.2.pre5\hew\jsp\tools\H8S-RENESAS\sample
CPU SERIES :	2000
CPU TYPE :	2338F
TOOLCHAIN NAME :	Hitachi H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	6.1.0.0
GENERATION FILES :
    D:\cygwin\home\Administrator\tmp\jsp-1.4.2.pre5\hew\jsp\tools\H8S-RENESAS\sample\dbsct.c
        Setting of B,R Section
    D:\cygwin\home\Administrator\tmp\jsp-1.4.2.pre5\hew\jsp\tools\H8S-RENESAS\sample\typedefine.h
        Aliases of Integer Type
START ADDRESS OF SECTION :
    H'000000800	P,C,C$DSEC,C$BSEC,D
    H'000FFDC00	B,R
    H'000FFF9F0	S

* When the user program is executed,
* the interrupt mask has been masked.
* 
* ****H8S/2338F Advanced****

DATE & TIME : 2005/12/06 15:24:13
