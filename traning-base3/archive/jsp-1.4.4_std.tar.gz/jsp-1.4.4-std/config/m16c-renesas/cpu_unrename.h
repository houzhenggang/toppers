/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#undef activate_r
#undef ret_int
#undef interrupt
#undef intnest
#undef break_wait

#ifdef LABEL_ASM

#undef _activate_r
#undef _ret_int
#undef _interrupt
#undef _intnest
#undef _break_wait

#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
