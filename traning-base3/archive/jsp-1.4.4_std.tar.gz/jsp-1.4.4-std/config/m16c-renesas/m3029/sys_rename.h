/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#ifndef OMIT_RENAME


#ifdef LABEL_ASM


#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _SYS_RENAME_H_ */
