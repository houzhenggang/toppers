/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

#undef make_priority_mask
#undef device_dispatcher
#undef boot_for_gdb

#ifdef LABEL_ASM

#undef _make_priority_mask
#undef _device_dispatcher
#undef _boot_for_gdb

#endif /* LABEL_ASM */
#endif /* _SYS_UNRENAME_H_ */
