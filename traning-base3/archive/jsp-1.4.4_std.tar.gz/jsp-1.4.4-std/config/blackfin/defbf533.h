/************************************************************************
 *
 * defbf533.h
 *
 * (c) Copyright 2001-2003 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#ifndef _DEFBF533_H
#define _DEFBF533_H

#include <defbf532.h>

#endif /* _DEFBF533_H */
