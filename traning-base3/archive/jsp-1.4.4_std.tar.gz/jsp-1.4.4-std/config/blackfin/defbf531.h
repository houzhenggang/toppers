/************************************************************************
 *
 * defbf531.h
 *
 * (c) Copyright 2001-2003 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#ifndef _DEFBF531_H
#define _DEFBF531_H

#include <defbf532.h>

#endif /* _DEFBF531_H */
