/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#undef activate_r
#undef dispatch
#undef dev_vector
#undef exc_vector
#undef device_dispatcher
#undef interrupt_dispatcher
#undef task_context
#undef expEntry
#undef nmiEntry
#undef ivTMREntry
#undef ivHWEntry
#undef ivg7Entry
#undef ivg8Entry
#undef ivg9Entry
#undef ivg10Entry
#undef ivg11Entry
#undef ivg12Entry
#undef ivg13Entry
#undef ivg14Entry

#ifdef LABEL_ASM

#undef _activate_r
#undef _dispatch
#undef _dev_vector
#undef _exc_vector
#undef _device_dispatcher
#undef _interrupt_dispatcher
#undef _task_context
#undef _expEntry
#undef _nmiEntry
#undef _ivTMREntry
#undef _ivHWEntry
#undef _ivg7Entry
#undef _ivg8Entry
#undef _ivg9Entry
#undef _ivg10Entry
#undef _ivg11Entry
#undef _ivg12Entry
#undef _ivg13Entry
#undef _ivg14Entry

#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
