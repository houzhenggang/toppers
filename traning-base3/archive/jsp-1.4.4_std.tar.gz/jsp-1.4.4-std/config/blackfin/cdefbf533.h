/************************************************************************
 *
 * cdefbf533.h
 *
 * (c) Copyright 2002-2003 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#ifndef _CDEFBF533_H
#define _CDEFBF533_H

#include <cdefbf532.h>

#endif /* _CDEFBF533_H */
