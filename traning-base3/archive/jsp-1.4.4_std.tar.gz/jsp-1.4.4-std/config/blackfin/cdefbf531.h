/************************************************************************
 *
 * cdefbf531.h
 *
 * (c) Copyright 2002-2003 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#ifndef _CDEFBF531_H
#define _CDEFBF531_H

#include <cdefbf532.h>

#endif /* _CDEFBF531_H */
