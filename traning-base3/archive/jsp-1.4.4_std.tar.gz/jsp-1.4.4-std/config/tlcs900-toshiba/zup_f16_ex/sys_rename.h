/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#ifndef OMIT_RENAME

#define log_io_busy			_kernel_log_io_busy

#ifdef LABEL_ASM

#define _log_io_busy		__kernel_log_io_busy

#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _SYS_RENAME_H_ */
