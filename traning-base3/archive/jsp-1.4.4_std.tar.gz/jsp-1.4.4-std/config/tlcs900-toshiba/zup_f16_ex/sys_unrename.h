/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_RENAME_H_
#undef _SYS_RENAME_H_

#ifndef OMIT_RENAME

#undef log_io_busy

#ifdef LABEL_ASM

#undef _log_io_busy

#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _SYS_RENAME_H_ */
