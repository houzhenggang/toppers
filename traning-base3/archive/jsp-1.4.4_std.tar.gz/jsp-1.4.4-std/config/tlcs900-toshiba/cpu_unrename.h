/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_RENAME_H_
#undef _CPU_RENAME_H_

#ifndef OMIT_RENAME

#undef intcnt
#undef task_intmask
#undef int_intmask
#undef activate_r
#undef interrupt
#undef task_intmask
#undef int_intmask

#ifdef LABEL_ASM

#undef _intcnt
#undef _task_intmask
#undef _int_intmask
#undef _activate_r
#undef _interrupt
#undef _task_intmask
#undef _int_intmask

#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _CPU_RENAME_H_ */
