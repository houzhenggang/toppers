/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#undef activate_r
#undef ret_int
#undef ret_exc
#undef 

#ifdef LABEL_ASM

#undef _activate_r
#undef _ret_int
#undef _ret_exc

#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
