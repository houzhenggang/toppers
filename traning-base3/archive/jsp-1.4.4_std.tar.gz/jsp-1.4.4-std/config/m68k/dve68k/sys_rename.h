/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#define board_id		_kernel_board_id
#define board_addr		_kernel_board_addr

#ifdef LABEL_ASM

#define _board_id		__kernel_board_id
#define _board_addr		__kernel_board_addr

#endif /* LABEL_ASM */
#endif /* _SYS_RENAME_H_ */
