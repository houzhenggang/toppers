/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

#undef board_id
#undef board_addr

#ifdef LABEL_ASM

#undef _board_id
#undef _board_addr

#endif /* LABEL_ASM */
#endif /* _SYS_UNRENAME_H_ */
