/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_RENAME_H_
#undef _SYS_RENAME_H_

/*
 * sys_config.h
 */
#undef cpu_putc

#ifdef LABEL_ASM

/*
 * sys_config.h
 */
#undef _cpu_putc

#endif /* LABEL_ASM */
#endif /* _SYS_RENAME_H_ */
