/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

/*
 * sys_config.c
 */
#undef load_vector
#undef save_vector

/*
 * sys_config.c(cpu_config.c)
 */
#undef cpu_putc


#ifdef LABEL_ASM

/*
 * sys_config.c
 */
#undef _load_vector
#undef _save_vector

/*
 * sys_config.c(cpu_config.c)
 */
#undef _cpu_putc


#endif /* LABEL_ASM */
#endif /* _SYS_UNRENAME_H_ */
