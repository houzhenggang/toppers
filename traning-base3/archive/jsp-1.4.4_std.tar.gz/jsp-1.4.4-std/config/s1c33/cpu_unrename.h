/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

/*
 * cpu_config.c
 */
#undef cpu_terminate
#undef activate_r
#undef dispatch
#undef exit_and_dispatch
#undef ret_int
#undef ena_int
#undef dis_int
#undef clr_int
#undef tps_IntNestCnt
#undef tps_OrgIntLevel
#undef init_lib
#undef init_sys

#ifdef LABEL_ASM

/*
 * cpu_config.c
 */
#undef _cpu_terminate
#undef _activate_r
#undef _dispatch
#undef _exit_and_dispatch
#undef _ret_int
#undef _ena_int
#undef _dis_int
#undef _clr_int
#undef _tps_IntNestCnt
#undef _tps_OrgIntLevel
#undef _init_lib
#undef _init_sys

#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
