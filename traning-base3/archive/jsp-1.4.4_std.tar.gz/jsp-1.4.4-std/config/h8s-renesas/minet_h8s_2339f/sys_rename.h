/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#define sys_putc		_kernel_sys_putc

#ifdef LABEL_ASM

#define _sys_putc		__kernel_sys_putc

#endif /* LABEL_ASM */
#endif /* _SYS_RENAME_H_ */
