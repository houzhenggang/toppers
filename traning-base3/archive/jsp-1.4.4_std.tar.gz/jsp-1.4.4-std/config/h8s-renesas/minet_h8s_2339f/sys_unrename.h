/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

#undef sys_putc

#ifdef LABEL_ASM

#undef _sys_putc

#endif /* LABEL_ASM */
#endif /* _SYS_UNRENAME_H_ */
