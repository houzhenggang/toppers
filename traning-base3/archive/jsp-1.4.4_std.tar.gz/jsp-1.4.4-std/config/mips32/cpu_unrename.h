/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#undef activate_r
#undef ret_int
#undef ret_exc
#undef int_intmask
#undef general_exception
#undef cpu_experr
#undef join_interrupt_and_exception
#undef exc_table
#undef int_table
#undef sil_dly_nse_asm

#ifdef LABEL_ASM

#undef _activate_r
#undef _ret_int
#undef _ret_exc
#undef _int_intmask
#undef _general_exception
#undef _cpu_experr
#undef _join_interrupt_and_exception
#undef _exc_table
#undef _int_table
#undef _sil_dly_nse_asm

#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
