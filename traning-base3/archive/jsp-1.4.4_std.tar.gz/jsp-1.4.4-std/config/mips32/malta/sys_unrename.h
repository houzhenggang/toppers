/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

#undef icu_intmask_table
#undef proc_interrupt_sys

#ifdef LABEL_ASM

#undef _icu_intmask_table
#undef _proc_interrupt_sys

#endif /* LABEL_ASM */
#endif /* _SYS_UNRENAME_H_ */
