/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#define icu_intmask_table	_kernel_icu_intmask_table
#define proc_interrupt_sys	_kernel_proc_interrupt_sys

#ifdef LABEL_ASM

#define _icu_intmask_table	__kernel_icu_intmask_table
#define _proc_interrupt_sys	__kernel_proc_interrupt_sys

#endif /* LABEL_ASM */
#endif /* _SYS_RENAME_H_ */
