/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#ifndef OMIT_RENAME

#undef activate_r
#undef ret_int
#undef ret_exc
#undef interrupt_count
#undef int_handler_table
#undef int_bit_table
#undef exception_entry
#undef interrupt_entry


#ifdef LABEL_ASM

#undef _activate_r
#undef _ret_int
#undef _ret_exc
#undef _interrupt_count
#undef _int_handler_table
#undef _int_bit_table
#undef _exception_entry
#undef _interrupt_entry


#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _CPU_UNRENAME_H_ */
