/* This file is generated from cpu_rename.def by genrename. */

#ifdef _CPU_UNRENAME_H_
#undef _CPU_UNRENAME_H_

#undef activate_r  
#undef ret_int     
#undef ret_exc     
#undef task_intmask
#undef int_intmask 
#undef int_table
#undef int_plevel_table
#undef exc_table
#undef BASE_VBR
#undef general_exception
#undef no_reg_interrupt
#undef cpu_expevt
#undef cpu_interrupt


#ifdef LABEL_ASM

#undef _activate_r  
#undef _ret_int     
#undef _ret_exc     
#undef _task_intmask
#undef _int_intmask 
#undef _int_table
#undef _int_plevel_table
#undef _exc_table
#undef _BASE_VBR
#undef _general_exception
#undef _no_reg_interrupt
#undef _cpu_expevt
#undef _cpu_interrupt


#endif /* LABEL_ASM */
#endif /* _CPU_UNRENAME_H_ */
