/* This file is generated from cpu_rename.def by genrename. */

#ifndef _CPU_RENAME_H_
#define _CPU_RENAME_H_

#define activate_r		_kernel_activate_r


#ifdef LABEL_ASM

#define _activate_r		__kernel_activate_r


#endif /* LABEL_ASM */
#endif /* _CPU_RENAME_H_ */
