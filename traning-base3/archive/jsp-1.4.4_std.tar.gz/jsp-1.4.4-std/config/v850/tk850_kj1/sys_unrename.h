/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_RENAME_H_
#undef _SYS_RENAME_H_

#undef hardware_init_hook


#ifdef LABEL_ASM

#undef _hardware_init_hook


#endif /* LABEL_ASM */
#endif /* _SYS_RENAME_H_ */
