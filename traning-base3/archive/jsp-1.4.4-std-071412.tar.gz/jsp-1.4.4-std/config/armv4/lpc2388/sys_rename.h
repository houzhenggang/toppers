/* This file is generated from sys_rename.def by genrename. */

#ifndef _SYS_RENAME_H_
#define _SYS_RENAME_H_

#ifndef OMIT_RENAME

#define int_table		_kernel_int_table
#define int_mask_table		_kernel_int_mask_table

#ifdef LABEL_ASM

#define _int_table		__kernel_int_table
#define _int_mask_table		__kernel_int_mask_table

#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _SYS_RENAME_H_ */
