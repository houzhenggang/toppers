#ifndef _TINET_ID_H_
#define _TINET_ID_H_

#include "tinet_cfg.h"

#endif	/* of _TINET_ID_H_*/
